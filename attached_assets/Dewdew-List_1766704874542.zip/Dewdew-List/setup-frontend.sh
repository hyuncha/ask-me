#!/bin/bash
cd /home/runner/workspace/frontend
npm install --legacy-peer-deps
